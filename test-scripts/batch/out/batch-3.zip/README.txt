Provider: mock
Zip this folder and upload via /admin/batches
Expected: at least one failing item if warning omitted