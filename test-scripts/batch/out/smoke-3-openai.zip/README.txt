Provider: openai
Model: gpt-image-1 quality=low size=1024x1024
Items: 3 pass=2 fail=1
Zip this folder and upload via /admin/batches