Provider: mock
Model: gpt-image-1 quality=low size=1024x1024
Items: 300 pass=225 fail=75
Zip this folder and upload via /admin/batches